This mod called the Endersword is a mod which adds an invincible sword in minecraft which has an enderman texture to it

It only works on Minecraft Forge 1.18 and 1.19