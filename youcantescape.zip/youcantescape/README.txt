- You can't escape.exe

This Program is a joke virus kind of like the program "Hydra.exe" since it performs almost the same way with spamming windows and not letting you close the windows and instead multiplying them, there may be a few issues with this program since this is not programmed to be a perfectly working joke program
How to remove the changes

- How to Remove the Changes

In the program there are a few registry keys that are added that will disable task manager and command prompt so you will need to delete them Open Regedit.exe and Navigate to HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System Once you navigate there delete the key "DisableTaskMgr"

Then Navigate to HKEY_CURRENT_USER\SOFTWARE\Policies\Microsoft\Windows\System Once you navigate there, delete DisableCMD and reboot